
local Rectangle = {area = 0, length = 0, breadth = 0}

function Rectangle:new (o,length,breadth)
end


function Rectangle:printArea ()
end

return Rectangle